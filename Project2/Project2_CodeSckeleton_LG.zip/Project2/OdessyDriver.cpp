// CSCI 1300 Spring 2024
// Author: Lucas Garcia
// TA: Elsie Tate
// OdessyDriver.cpp

#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <cmath>
#include <algorithm>
#include <stdio.h>     
#include <stdlib.h>     
#include <time.h>
#include "Map.h"
#include "Entity.h"
#include "Game.h"
using namespace std;

bool loadCharacters(string filename, Entity characters[], const int CHARACTERS_SIZE, bool is_enemy);

int main() {

    srand(time(nullptr)); // Seed the random number generator

    // Test Entity class
    Entity player1("Player1", 100.0, 50, 'H', false);
    Entity enemy1("Enemy1", 80.0, 30, 'P', true);

    cout << "Player 1 stats:" << endl;
    player1.printStats();
    cout << endl;

    cout << "Enemy 1 stats:" << endl;
    enemy1.printStats();
    cout << endl;

    // Test Game class
    Entity players[] = {player1};
    Entity enemies[] = {enemy1};
    Game game(players, enemies, 1, 1);

    cout << "Number of players: " << game.getNumPlayers() << endl;
    cout << "Number of enemies: " << game.getNumEnemies() << endl << endl;

    cout << "All stats:" << endl;
    game.printAllStats();
    cout << endl;

    // Test loadCharacters function
    const int CHARACTERS_SIZE = 2;
    Entity characters[CHARACTERS_SIZE];

    if (loadCharacters("characters.txt", characters, CHARACTERS_SIZE, true)) {
        cout << "Characters loaded successfully!" << endl;
        cout << "Printing loaded characters:" << endl;
        for (int i = 0; i < CHARACTERS_SIZE; i++) {
            characters[i].printStats();
        }
    } else {
        cout << "Failed to load characters!" << endl;
    }

    cout << endl << "Now Test Map" << endl;

    // Test Map class
    Map map(2, 50);
    map.initializeMap();

    cout << "Map initialization completed!" << endl;

    map.printMap();

    return 0;
}

bool loadCharacters(std::string filename, Entity characters[], const int CHARACTERS_SIZE, bool is_enemy) 
{
    ifstream file(filename);
    if (!file.is_open()) 
    {
        return false;
    }

    string line;
    getline(file, line); // Skip headers

    for (int index = 0; index < CHARACTERS_SIZE && getline(file, line); index++) {
        stringstream ss(line);
        string name, HP_str, gold_str, condition_str;

        if (getline(ss, name, '|') && getline(ss, HP_str, '|') && getline(ss, gold_str, '|') && getline(ss, condition_str)) 
        {
            if (name.empty() || HP_str.empty() || gold_str.empty() || condition_str.empty())
                continue;

            double HP = stod(HP_str);
            int gold = stoi(gold_str);
            char condition = condition_str[0];

            characters[index] = Entity(name, HP, gold, condition, is_enemy);
        }
    }

    file.close();
    return true;
}
