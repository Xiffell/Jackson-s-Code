// CSCI 1300 Spring 2024
// Author: Lucas Garcia
// TA: Elsie Tate
// Entity.cpp

#include <iostream>
#include "Entity.h"
using namespace std;

Entity::Entity()
{
    _gold = 0;
    _hp = 0;
    _name = "";
    _condition = 'H';
    _is_enemy = false;
}

Entity::Entity(string name, double hp, int gold, char condidtion, bool enemy)
{
    _gold = (gold >= 0) ? gold : 0;
    _hp = (hp >= 0) ? hp : 0;
    _name = name;
    _condition = (condidtion == 'H' || condidtion == 'D' || condidtion == 'P') ? condidtion : 'H';
    _is_enemy = enemy;
}

string Entity::getName()
{
    return _name;
}

double Entity::getHP()
{
    return _hp;
}

char Entity::getCondition()
{
    return _condition;
}

int Entity::getGold()
{
    return _gold;
}

bool Entity::getIsEnemy()
{
    return _is_enemy;
}

void Entity::setName(string name)
{
    _name = name;
}

void Entity::setHP(double hp)
{
    if (hp >= 0)
    {
        _hp = hp;
    }
}

void Entity::setCondition(char condition)
{
    if (condition == 'H' || condition == 'D' || condition == 'P')
    {
        _condition = condition;
    }
    else
    {
        _condition = _condition;
    }
}

void Entity::setGold(int gold)
{
    if (gold >= 0)
    {
        _gold = gold;
    }
}

void Entity::setIsEnemy(bool is_enemy)
{
    _is_enemy = is_enemy;
}

void Entity::printStats()
{
    cout << _name << "'s stats:" << endl;
    cout << "HP: " << fixed << setprecision(2) << _hp << endl;
    cout << "Condition: " << _condition << endl;
    cout << "Gold: " << _gold << endl;
    cout << "Is Enemy: " << (_is_enemy ? "Yes" : "No") << endl;
}