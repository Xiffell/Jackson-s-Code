// CSCI 1300 Spring 2024
// Author: Lucas Garcia
// TA: Elsie Tate
// Map.cpp

#include <iostream>
#include "Map.h"
using namespace std;

#define RED "\033[41m"     // Red
#define GREEN "\033[42m"   // Green
#define BLUE "\033[44m"    // Blue
#define MAGENTA "\033[45m" // Magenta
#define CYAN "\033[46m"    // Cyan
#define RESET "\033[0m"

Map::Map() {}

Map::Map(int players_num, int size)
{
    cout << "Created a Map Array!" << endl;
    m_mapArr[players_num][size] = {};
}

// setter for position on map given the value and which player and then the index for their lane
void Map::setMapPos(string value, int playerID, int index)
{
    m_mapArr[playerID][index] = value;
}

// getter for position on map given which player and then the index for their lane
string Map::getMapPos(int playerID, int index)
{
    return m_mapArr[playerID][index];
}

void Map::initializeMap()
{
    cout << "Indisde Initialize Map" << endl;

    m_mapArr[0][0] = BLUE;
    m_mapArr[1][0] = BLUE;

    m_mapArr[0][49] = MAGENTA;
    m_mapArr[1][49] = MAGENTA;

    for (int i = 1; i < 49; i++)
    {
        //srand(time(nullptr)); // Seed the random number generator

        for (int i = 0; i < 2; ++i)
        {
            for (int j = 1; j < 49; ++j)
            {
                int rand_num = rand() % 3; // Generate a random number between 0 and 2

                // Assign color based on the random number
                switch (rand_num)
                {
                case 0:
                    m_mapArr[i][j] = RED;
                    break;
                case 1:
                    m_mapArr[i][j] = GREEN;
                    break;
                case 2:
                    m_mapArr[i][j] = BLUE;
                    break;
                }
            }
        }
    }
}

void Map::printMap()
    {
        for (int i = 0; i < 2; ++i)
        {
            for (int j = 0; j < 50; ++j)
            {
                cout << m_mapArr[i][j];
            }
            cout << endl;
        }
    }