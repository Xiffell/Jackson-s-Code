// CSCI 1300 Spring 2024
// Author: Lucas Garcia
// TA: Elsie Tate
// Game.cpp

#include <iostream>
#include "Game.h"
#include "Entity.h"
using namespace std;

Game::Game()
{
    _num_enemies = 0;
    _num_players = 0;
}

Game::Game(Entity players[], Entity enemies[], int num_players, int num_enemies)
{
    _num_players = (num_players > 2) ? 2 : num_players;
    _num_enemies = (num_enemies > 2) ? 2 : num_enemies;

    for (int i = 0; i < _num_players; i++)
    {
        _players[i] = players[i];
        _enemies[i] = enemies[i];
    }
}

int Game::getNumPlayers()
{
    return _num_players;
}

int Game::getNumEnemies()
{
    return _num_enemies;
}

void Game::setPlayersList(Entity players[], int size)
{
    _num_players = (size > 2) ? 2 : size;

    for (int i = 0; i < _num_players; i++)
    {
        _players[i] = players[i];
    }
}

void Game::setEnemiesList(Entity enemies[], int size)
{
    _num_enemies = (size > 2) ? 2 : size;

    for (int i = 0; i < _num_enemies; i++)
    {
        _enemies[i] = enemies[i];
    }
}

bool Game::setPlayer(int index, Entity new_player)
{
    if (index >= 0 && index < _num_players)
    {
        _players[index] = new_player;
        return true;
    }
    else
    {
        return false;
    }
}

bool Game::setEnemy(int index, Entity new_enemy)
{
    if (index >= 0 && index < _num_enemies)
    {
        _enemies[index] = new_enemy;
        return true;
    }
    else
    {
        return false;
    }
}

Entity Game::getPlayer(string name)
{
    for (int i = 0; i < _num_players; i++)
    {
        if (_players[i].getName() == name)
        {
            return _players[i];
        }
    }

    return Entity();
}

Entity Game::getEnemy(string name)
{
    for (int i = 0; i < _num_enemies; i++)
    {
        if (_enemies[i].getName() == name)
        {
            return _enemies[i];
        }
    }

    return Entity();
}

int Game::findPlayer(string name)
{
    for (int i = 0; i < _num_players; i++)
    {
        if (name == _players[i].getName())
        {
            return i;
        }
    }
    return -1;
}

int Game::findEnemy(string name)
{
    for (int i = 0; i < _num_enemies; i++)
    {
        if (name == _enemies[i].getName())
        {
            return i;
        }
    }
    return -1;          
}

void Game::printAllStats()
{
    for (int i = 0; i < _num_players; i++)
    {
        _players[i].printStats();
        cout << "----------------------------------------------" << endl;
    }

    for (int j = 0; j < _num_enemies; j++)
    {
        _enemies[j].printStats();
        cout << "----------------------------------------------" << endl;;
    }
}