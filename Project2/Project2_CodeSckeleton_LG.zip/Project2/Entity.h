// CSCI 1300 Spring 2024
// Author: Lucas Garcia
// TA: Elsie Tate
// Entity.h

#include <iostream>
#include <iomanip>
using namespace std;

#ifndef Entity_H
#define Entity_H

class Entity
{
    private:

        string _name;
        double _hp;
        int _gold;
        char _condition;
        bool _is_enemy;

    public:

        Entity();

        Entity(string, double, int, char, bool);

        string getName();

        double getHP();

        char getCondition();

        int getGold();

        bool getIsEnemy();

        void setName(string name);

        void setHP(double hp);

        void setCondition(char condition);

        void setGold(int gold);

        void setIsEnemy(bool is_enemy);

        void printStats();

};

#endif